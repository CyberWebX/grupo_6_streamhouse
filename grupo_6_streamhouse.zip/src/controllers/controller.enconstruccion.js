const controladorEnconstruccion = {

    enconstruccion: function (req, res){
        res.render("./enconstruccion/enconstruccion");
    }

}

//Exportar

module.exports = controladorEnconstruccion;