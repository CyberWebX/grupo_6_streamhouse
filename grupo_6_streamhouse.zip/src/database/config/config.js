module.exports = 
{
  "development": {
    "username": "cyberweb_streamhouse6",
    "password": "DigitalHouse6?",
    "database": "cyberweb_streamhouse",
    "host": "168.194.198.1",
    "dialect": "mysql"
  },
  "test": {
    "username": "cyberweb_streamhouse6",
    "password": "DigitalHouse6?",
    "database": "cyberweb_streamhouse",
    "host": "168.194.198.1",
    "dialect": "mysql"
  },
  "production": {
    "username": "cyberweb_streamhouse6",
    "password": "DigitalHouse6?",
    "database": "cyberweb_streamhouse",
    "host": "168.194.198.1",
    "dialect": "mysql"
  }
}
